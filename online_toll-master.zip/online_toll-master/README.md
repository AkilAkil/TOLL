# online_toll
online payment for tolls and number plate recoginition using php,python &amp;ocr
